# practic movie app

## images

1. https://picsum.photos/id/1003/1181/1772 deer
2. https://picsum.photos/id/1006/3000/2000 mountain
3. https://picsum.photos/id/1015/6000/4000 river


###

1. padaryti kad paspadus istrinti, atsiratu istynimo modalas. pati modala galim atsaukti, tai nutraukia istrynima. jei paspaudziam patvirtinti, tai toliau vyksta istrynimas.

2. prisideti filtra filtruoti pagal title

3. jei per sunku. Tai gryztam i init saka ir pradedam viska nuo pradziu. atliekam panasiai tuos pacius funkcionalumo dalykus