# practic movie app

## images

1. https://picsum.photos/id/1003/1181/1772 deer
2. https://picsum.photos/id/1006/3000/2000 mountain
3. https://picsum.photos/id/1015/6000/4000 river