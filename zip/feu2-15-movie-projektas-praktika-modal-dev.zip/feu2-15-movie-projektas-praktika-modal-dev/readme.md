# practic movie app

## images

1. https://picsum.photos/id/1003/1181/1772 deer